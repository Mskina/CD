package distancia;

public class Main {

    public static void main(String[] args) throws Exception {
        depuracion_Pruebas();
        
        //refactorizacion_Documentacion();
    }
    
    public static void depuracion_Pruebas() throws Exception{
        // Depuracion. Se detiene siempre
    	CDeposito miDeposito = new CDeposito();
    	
    	System.out.println("Contenido Inicial: " + miDeposito.litros + " L");
    	// Depuracion. Provoca parada por usar cantidad menor de 0
    	miDeposito.llenarPruebas(-100);
    	System.out.println("Contenido Inicial: " + miDeposito.litros + " L");
    	miDeposito.llenarPruebas(100);
    	System.out.println("Contenido tras llenado: " + miDeposito.litros + " L");
    	miDeposito.llenarPruebas(200);
    	System.out.println("Contenido tras llenado: " + miDeposito.litros + " L");
    	// Depuracion. Provoca parada con codicion de tercer aumento litros
    	miDeposito.llenarPruebas(300);
    	System.out.println("Contenido tras llenado: " + miDeposito.litros + " L");
    	miDeposito.quitarPruebas(50);
    	System.out.println("Contenido tras vaciado: " + miDeposito.litros + " L");

    }
    
    public static void refactorizacion_Documentacion(){
        CDeposito miDeposito;
        double litrosLitrosActual;

        miDeposito = new CDeposito("Paco Pérez","1000-2365",3500,0);
        litrosLitrosActual = miDeposito.estado();
        System.out.println("El contenido actual de litros es "+ litrosLitrosActual );

        try {
            miDeposito.quitar(1300);
        } catch (Exception e) {
            System.out.print("Fallo al retirar líquido");
        }
        try {
            System.out.println("Llenado en depósito");
            miDeposito.llenar(775);
        } catch (Exception e) {
            System.out.print("Fallo al ingresar líquido");
        }
        
        System.out.println("La cantidad actual de litros es "+ miDeposito.estado() );
    }
}
