package distancia;

public class CDeposito {


    public String propietario;
    public String id;
    public double litros;
    public double tipoReduccion;

    public CDeposito()
    {
    }

    public CDeposito(String nom, String id, double lit, double tipo)
    {
        propietario =nom;
        id=id;
        litros=lit;
    }

    public double estado()
    {
        return litros;
    }

    /* Metodo para llenar cantidades en la id. Modifica el litros.
     * Este metodo va a ser probado para refactorización
     */
    public void llenar(double cantidad) throws Exception
    {
        if (cantidad<0)
            throw new Exception("Optimiz_Doc: No se puede llenar una cantidad negativa");
        litros = litros + cantidad;
    }

    /* Metodo para quitar cantidades en la id. Modifica el litros.
     * Este metodo va a ser usado para Refactorización
     */
    public void quitar(double cantidad) throws Exception
    {
        if (cantidad <= 0)
            throw new Exception ("Optimiz_Doc: No se puede quitar una cantidad negativa");
        if (estado()< cantidad)
            throw new Exception ("Optimiz_Doc: No se hay suficiente litros");
        litros = litros - cantidad;
    }
    
    /* Metodo para llenar cantidades en la id. Modifica el litros.
     * Este metodo va a ser probado con Junit
     */
    public int llenarPruebas(double cantidad) 
    {
    	int iCodErr;
    	
        if (cantidad < 0)
        {
        	System.out.println("Depurac_Pruebas: No se puede llenar una cantidad negativa");
        	iCodErr = 1;
        }
        else if (cantidad == -7)
        {
            System.out.println("Depurac_Pruebas: Error detectable en pruebas de caja blanca");
        	iCodErr = 2;
        }
        else
        {
        	// Depuracion. Punto de parada. Solo en el 3 ingreso        
                litros = litros + cantidad;
        	iCodErr = 0;
        }
        
    	// Depuracion. Punto de parada cuando la cantidad  es menor de 0        
        return iCodErr;
    }

    /* Metodo para quitar cantidades en la id. Modifica el litros.
     * Este metodo va a ser probado con Junit
     */
    public double quitarPruebas (double cantidad) 
    {
        if (cantidad <= 0)
        {
            System.out.println("Depurac_Pruebas: No se puede quitar una cantidad negativa");
        }
        else if (litros < cantidad)
        {
            System.out.println("Depurac_Pruebas: No hay suficiente litros");
        }
        else
        {
        	
                litros = litros - cantidad;
        }
        
        return litros;
    }
}
